<!DOCTYPE html>
@extends("layouts.app")
<html>
<head>
  <link rel="stylesheet" href="css/login.css">
</head>
<h1>Contact us at ABC123</h1>
</html>