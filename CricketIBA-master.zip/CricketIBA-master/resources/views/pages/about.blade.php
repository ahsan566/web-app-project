<!DOCTYPE html>
@extends("layouts.app")
<html>
<head>
  <link rel="stylesheet" href="css/login.css">
</head>
<h1>This is the about page</h1>
</html>